#uploading the csv data file to the environment
funding.df <- read.csv("TechCrunchcontinentalUSA.csv")
#the only category with NAs was number of employees, since we use the number of employees in models, we want to get rid of them 
funding.df <- na.omit(funding.df)
summary(funding.df)

#Step 1

  library(ggplot2)
  #histogram of log raised amount
  hist <- hist(log(funding.df$raisedAmt))
  sd(funding.df$raisedAmt)

  #histograms of raised amount based on category
  plot(funding.df$category, log(funding.df$raisedAmt))
  
  #point chart that shows the round for each category of company and the log of amount raised at each point
  sp <- ggplot(funding.df, aes(x=category, y=log(raisedAmt))) + geom_point(shape=1)
  
  sp + facet_grid(funding.df$round~.)
  
  #experimenting with the deometric density graph with round and raised amount
  
  ggplot(funding.df, aes(x = as.numeric(round),y =raisedAmt)) + geom_density2d()
  
  #dot plot of amount each round of raising showed up in the data file
  
  ggplot(funding.df, aes(x = round)) + geom_dotplot(binwidth = .03)
  
  #three bar charts of how much round state, and category appeared in the data filee
  
  ggplot(funding.df, aes(x = round)) + geom_bar()
  ggplot(funding.df, aes(x = state)) + geom_bar()
  ggplot(funding.df, aes(x = category)) + geom_bar()
  
  #various histograms showing raised amount in each round
  
  ggplot(funding.df, aes(x = round,y =raisedAmt)) + geom_boxplot()
  
  #experimeting with other types of graphs
  
  library("hexbin")
  ggplot(funding.df, aes(x = round,y =raisedAmt)) + geom_hex()
  ggplot(funding.df, aes(x = round,y =raisedAmt)) + geom_jitter()
  

  
#Step 2  

  #finding best predictors for raised amount by eliminating non-essential coefficients

  fitall <- lm(raisedAmt ~ numEmps+as.numeric(category)+as.numeric(city)+as.numeric(state)+as.numeric(round), data = funding.df)
  summary(fitall)

  fitall <- lm(raisedAmt ~ numEmps+as.numeric(category)+as.numeric(city), data = funding.df)
  summary(fitall)

  fitall <- lm(raisedAmt ~ numEmps+as.numeric(category)+as.numeric(round), data = funding.df)
  summary(fitall)
  
  fitall <- lm(raisedAmt ~ numEmps+as.numeric(category), data = funding.df)
  summary(fitall)

  #predictions based on number of employees and category

  train.size <- .75 #training set size
  data.size <- nrow(funding.df)
  set.seed(1234)
  train.rows.nums <- sample(1:data.size, data.size * train.size, replace = FALSE)
  train.data <- subset(funding.df[train.rows.nums,]) 
  test.data <- subset(funding.df[-train.rows.nums,])
  
  fit.train <- lm(raisedAmt ~ numEmps+as.numeric(category), data = train.data) 
  summary(fit.train) 

  actual_scores <- funding.df$raisedAmt[-train.rows.nums]

  fit.predicted <-predict(fit.train, test.data, interval = "predict", level=0.95) 
  head(fit.predicted)
  predicted_scores <- fit.predicted[,1]

  mse.test <- mean((actual_scores - predicted_scores)^2)
  mse.train <- mean(fit.train$residuals^2)

  percentchange <- ((mse.train - mse.test)/mse.train) *100
  percentchange

  diffofmeans <- mean(actual_scores)- mean(predicted_scores)

  diffofmeans

  #prediction based on number of employees, category, and the relationship of the two

  train.size <- .75
  data.size <- nrow(funding.df)
  set.seed(1234)
  train.rows.nums <- sample(1:data.size, data.size * train.size, replace = FALSE)
  train.data <- subset(funding.df[train.rows.nums,])
  test.data <- subset(funding.df[-train.rows.nums,])

  fit.train <- lm(raisedAmt ~ numEmps+as.numeric(category)+numEmps:as.numeric(category), data = train.data)
  summary(fit.train)

  actual_scores <- funding.df$raisedAmt[-train.rows.nums]

  fit.predicted <-predict(fit.train, test.data, interval = "predict", level=0.95) 
  head(fit.predicted)
  predicted_scores <- fit.predicted[,1]

  mse.test <- mean((actual_scores - predicted_scores)^2)
  mse.train <- mean(fit.train$residuals^2)

  percentchange <- ((mse.train - mse.test)/mse.train) *100
  percentchange

  diffofmeans <- mean(actual_scores)- mean(predicted_scores)

  diffofmeans

  #prediction based on number of employees, category, and state
  train.size <- .75
  data.size <- nrow(funding.df)
  set.seed(1234)
  train.rows.nums <- sample(1:data.size, data.size * train.size, replace = FALSE)
  train.data <- subset(funding.df[train.rows.nums,])
  test.data <- subset(funding.df[-train.rows.nums,])

  fit.train <- lm(raisedAmt ~ numEmps+as.numeric(category)+as.numeric(state), data = train.data)
  summary(fit.train)

  actual_scores <- funding.df$raisedAmt[-train.rows.nums]

  fit.predicted <-predict(fit.train, test.data, interval = "predict", level=0.95) 
  head(fit.predicted)
  predicted_scores <- fit.predicted[,1]

  mse.test <- mean((actual_scores - predicted_scores)^2)
  mse.train <- mean(fit.train$residuals^2)

  percentchange <- ((mse.train - mse.test)/mse.train) *100
  percentchange

  diffofmeans <- mean(actual_scores)- mean(predicted_scores)

  diffofmeans

  #prediction based on number of employees alone
  train.size <- .75
  data.size <- nrow(funding.df)
  set.seed(1234)
  train.rows.nums <- sample(1:data.size, data.size * train.size, replace = FALSE)
  train.data <- subset(funding.df[train.rows.nums,])
  test.data <- subset(funding.df[-train.rows.nums,])

  fit.train <- lm(raisedAmt ~ numEmps, data = train.data)
  summary(fit.train)

  actual_scores <- funding.df$raisedAmt[-train.rows.nums]

  fit.predicted <-predict(fit.train, test.data, interval = "predict", level=0.95) 
  head(fit.predicted)
  predicted_scores <- fit.predicted[,1]

  mse.test <- mean((actual_scores - predicted_scores)^2)
  mse.train <- mean(fit.train$residuals^2)

  percentchange <- ((mse.train - mse.test)/mse.train) *100
  percentchange

  diffofmeans <- mean(actual_scores)- mean(predicted_scores)

  diffofmeans

  #prediction based on the round in which the funding was raised
  train.size <- .75
  data.size <- nrow(funding.df)
  set.seed(1234)
  train.rows.nums <- sample(1:data.size, data.size * train.size, replace = FALSE)
  train.data <- subset(funding.df[train.rows.nums,])
  test.data <- subset(funding.df[-train.rows.nums,])

  fit.train <- lm(raisedAmt ~ as.numeric(round), data = train.data)
  summary(fit.train)

  actual_scores <- funding.df$raisedAmt[-train.rows.nums]

  fit.predicted <-predict(fit.train, test.data, interval = "predict", level=0.95) 
  head(fit.predicted)
  predicted_scores <- fit.predicted[,1]

  mse.test <- mean((actual_scores - predicted_scores)^2)
  mse.train <- mean(fit.train$residuals^2)

  percentchange <- ((mse.train - mse.test)/mse.train) *100
  percentchange

  diffofmeans <- mean(actual_scores)- mean(predicted_scores)

  diffofmeans

  mean((actual_scores - predicted_scores)/(mean(funding.df$raisedAmt)))

  summary(funding.df$category)



#Step 3 

  #deciding on proper ranges for categories of funding
  
  summary(funding.df$raisedAmt)
  #low: 0 - 1,000,000
  #lower middle: 1,000,000 - 8,763,929 
  #upper middle: 8,763,929 - 10,000,000
  #high: 10,000,000 - inf

  #cutting the raised amount category and assiging it to a new column in funding data file
  
  funding.df$cutRaised <- cut(funding.df$raisedAmt, breaks = c(0, 1000000, 8763929, 10000000, Inf), 
                            labels = c("low", "lower middle", "upper middle", "high"))

  summary(funding.df$cutRaised)

  train.size <- .75
  data.size <- nrow(funding.df)
  set.seed(1234)
  train.rows.nums <- sample(1:data.size, data.size * train.size, replace = FALSE)
  train.data <- subset(funding.df[train.rows.nums,])
  test.data <- subset(funding.df[-train.rows.nums,])

  class.labels <- funding.df$cutRaised[train.rows.nums]
  true.labels <- funding.df$cutRaised[-train.rows.nums]

  #library (e1071)
  
  #running the naiveBayes function on the new column 

  model <- naiveBayes(cutRaised ~.-raisedAmt, data = train.data)

  pred.labels <- predict(model, test.data)

  conf.matrix <- table(pred.labels,true.labels)
  conf.matrix

  num.incorrect.labels<-sum(conf.matrix[row(conf.matrix)!=col(conf.matrix)])
  misc.rate <- num.incorrect.labels/length(pred.labels)
  misc.rate

  # running a KFold Naive Bayes

  data.set <- funding.df # allows modifications that will not affect email.df.
  data.size <- nrow(data.set)
  data.cols <- ncol(data.set)
  num.folds <- 10

  set.seed(12345)
  data.set["fold"]<-floor(runif(data.size)*num.folds)+1
  data.set$fold<-factor(data.set$fold)
  misclassification.results <- c()

  for(i in c(1:num.folds)){
  
  train<-data.set[(data.set$fold!=i), 1:(data.cols)]
  test<-data.set[(data.set$fold==i),1:(data.cols)]
  
  model <- naiveBayes(cutRaised ~ -raisedAmt, data = train) 
  
  pred.labels <- predict(model, test[,-1]) 
 
  true.labels <- test[,11]
  
  num.incorrect.labels<-sum(pred.labels!=true.labels)
  
  misc.rate <- num.incorrect.labels/length(pred.labels)
  
  misclassification.results<-c(misclassification.results, misc.rate)
  }

  summary(misclassification.results)

  plot(misclassification.results, xlab="fold", ylab="misclassification rate")
  lines(misclassification.results)
  
  
  
  
 #Experimenting with shiny
  
  library("DT")
  library("shiny")
  library("dplyr")
  shinyApp(
    ui = fluidPage(
      selectInput("categories", "Pick a Category: ",
                  c("All" = "All Companies",
                    "biotech" = "biotech",
                    "cleantech" = "cleantech",
                    "consulting" = "consulting",
                    "hardware" = "hardware",
                    "mobile" = "mobile",
                    "other" = "other",
                    "software" = "software",
                    "web" = "web")),
      tableOutput("data")
    ),
    
    
    server = function(input, output) {
      
      output$data <-renderDataTable({
        
        funding.df
        
      })
      
    }
  )
